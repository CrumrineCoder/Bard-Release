(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vendor"],[
/* 0 */,
/* 1 */
/*!*******************!*\
  !*** multi react ***!
  \*******************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! react */"q1tI");


/***/ })
],[[1,"runtime","vendors"]]]);